<?php
// Silence is golden. And we agree :)
header('HTTP/1.0 404 Not Found', true, 404);
exit();
